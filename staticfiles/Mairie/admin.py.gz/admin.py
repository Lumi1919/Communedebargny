from django.contrib import admin
from .models import Album
from .models import Evenement
from .models import News
from .models import Avis
from .models import Une_photo
from .models import Doc
from .models import Bureau_municipal
from .models import Demarche


admin.site.register(Album)
admin.site.register(Evenement)
admin.site.register(News)
admin.site.register(Avis)
admin.site.register(Une_photo)
admin.site.register(Doc)
admin.site.register(Bureau_municipal)
admin.site.register(Demarche)


