from django.apps import AppConfig


class MairieConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Mairie'
